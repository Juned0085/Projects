from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from rest_framework import generics, permissions

from .forms import TaskStatusForm
from .models import Project, Task, ActivityLog
from .serializers import ProjectSerializer, TaskSerializer, RegisterSerializer, UserSerializer, ActivityLogSerializer
from django.contrib.auth import get_user_model,authenticate, login, logout
from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, HttpResponseForbidden
from .permissions import IsAdminUserCustom, IsAdmin, IsAdminOrTaskAssignee
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from django.core.mail import send_mail
from django.shortcuts import redirect


User = get_user_model()

class UserListView(generics.ListAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAdmin]

class RegisterView(generics.CreateAPIView):
    queryset = get_user_model().objects.all()
    serializer_class = RegisterSerializer
    permission_classes = [IsAdmin]  # Only admin can register users

class ProjectListCreateView(generics.ListCreateAPIView):
    queryset = Project.objects.all()
    serializer_class = ProjectSerializer

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    def get_permissions(self):
        if self.request.method == 'POST':
            return [IsAdmin()]
        return [permissions.IsAuthenticated()]

    def get_serializer_context(self):
        return {"request": self.request}


class TaskListCreateView(generics.ListCreateAPIView):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer

    def get_permissions(self):
        if self.request.method == 'POST':
            return [IsAdmin()]
        return [permissions.IsAuthenticated()]

    def get_serializer_context(self):
        return {'request': self.request}


class UserListView(generics.ListAPIView):
    queryset = get_user_model().objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAdminUser]  # Only admins can access

def home(request):
    return HttpResponse("Welcome to the Team Project & Task Management System!")

class DeleteUserView(generics.DestroyAPIView):
    queryset = User.objects.all()
    permission_classes = [IsAdminUserCustom]
    lookup_field = 'pk'  # Or 'id'

class ProjectDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Project.objects.all()
    serializer_class = ProjectSerializer
    permission_classes = [IsAdmin]

class TaskDetailView(generics.RetrieveUpdateAPIView):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer
    permission_classes = [permissions.IsAuthenticated, IsAdminOrTaskAssignee]

    def get_queryset(self):
        user = self.request.user
        if user.role == 'admin':
            return Task.objects.all()
        return Task.objects.filter(assigned_to=user)

class TaskListCreateView(generics.ListCreateAPIView):
    serializer_class = TaskSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.role == 'admin':
            return Task.objects.all()
        return Task.objects.filter(assigned_to=user)

    def perform_create(self, serializer):
        user = self.request.user
        if self.request.user.role != 'admin':
            raise PermissionDenied("Only admins can create tasks.")

        task = serializer.save()
        assigned_user = task.assigned_to

        # ✅ Console Notification
        print(f"✅ Task '{task.title}' assigned to {assigned_user.username} ({assigned_user.email})")

        # ✅ Email Notification (optional)
        send_mail(
            subject=f"New Task Assigned: {task.title}",
            message=f"""
        Hello {assigned_user.username},

        You have been assigned a new task:
        Title: {task.title}
        Project: {task.project.title}
        Due Date: {task.due_date}
        Priority: {task.priority}

        Please log in and check your task list.

        - Project Management System
        """,
            from_email='admin@new.com',  # Replace with your sender email
            recipient_list=[assigned_user.email],
            fail_silently=True
        )

class ActivityLogListView(generics.ListAPIView):
    queryset = ActivityLog.objects.all().order_by('-timestamp')
    serializer_class = ActivityLogSerializer
    permission_classes = [permissions.IsAdminUser]

    def get_queryset(self):
        queryset = ActivityLog.objects.all().order_by('-timestamp')

        # Get query parameters
        user_id = self.request.query_params.get('user')
        task_id = self.request.query_params.get('task')
        project_id = self.request.query_params.get('project')

        # Apply filters if present
        if user_id:
            queryset = queryset.filter(user__id=user_id)
        if task_id:
            queryset = queryset.filter(task__id=task_id)
        if project_id:
            queryset = queryset.filter(task__project__id=project_id)

        return queryset

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password')
    return render(request, 'login.html')
def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect('login')


@login_required
def dashboard_view(request):
    return render(request, 'dashboard.html', {'user': request.user})

@login_required
def task_list_view(request):
    tasks = Task.objects.filter(assigned_to=request.user)
    return render(request, 'tasks.html', {'tasks': tasks})


@login_required
def update_task_status(request, task_id):
    task = Task.objects.get(id=task_id)

    if request.method == 'POST':
        new_status = request.POST.get('status')
        task.status = new_status
        task.save()
        return redirect('my_tasks')  # Redirect back to the task list page

    return redirect('my_tasks')

@login_required
def my_tasks(request):
    user = request.user
    tasks = Task.objects.filter(assigned_to=user)
    return render(request, 'my_tasks.html', {'tasks': tasks})

@login_required
def user_tasks_view(request):
    user = request.user
    if user.role == 'admin':
        tasks = Task.objects.all()
    else:
        tasks = Task.objects.filter(assigned_to=user)
    return render(request, 'tasks.html', {'tasks': tasks})

@user_passes_test(lambda u: u.is_superuser)
def user_list(request):
    users = User.objects.all()
    return render(request, 'admin/user_list.html', {'users': users})

@user_passes_test(lambda u: u.is_superuser)
def project_list(request):
    projects = Project.objects.all()
    return render(request, 'admin/project_list.html', {'projects': projects})

@user_passes_test(lambda u: u.is_superuser)
def task_list_admin(request):
    tasks = Task.objects.all()
    return render(request, 'admin/task_list_admin.html', {'tasks': tasks})

@login_required
def view_my_tasks(request):
    tasks = Task.objects.filter(assigned_to=request.user)  # Ensure the user is assigned tasks
    return render(request, 'view_my_tasks.html', {'tasks': tasks})
