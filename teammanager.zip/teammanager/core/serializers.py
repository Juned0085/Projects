from rest_framework import serializers
from .models import User, Project, Task, ActivityLog
from django.contrib.auth import get_user_model


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = get_user_model()
        fields = ['id', 'username', 'email', 'role','is_superuser']

class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = get_user_model()
        fields = ['username', 'password', 'email', 'role']
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = get_user_model().objects.create_user(**validated_data)
        return user

class ProjectSerializer(serializers.ModelSerializer):
    created_by = serializers.ReadOnlyField(source='created_by.username')
    members = serializers.PrimaryKeyRelatedField(queryset=User.objects.all(), many=True)

    class Meta:
        model = Project
        fields = '__all__'

    def validate(self, data):
            request = self.context.get("request")
            if request and request.user.role != 'admin':
                raise serializers.ValidationError("Only admins can assign users to a project.")
            return data

class TaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = '__all__'

        def validate(self, data):
            request = self.context.get('request')
            if request and request.user.role != 'admin':
                raise serializers.ValidationError("Only admins can assign tasks to users.")
            return data

        def create(self, validated_data):
            task = super().create(validated_data)
            ActivityLog.objects.create(
                task=task,
                user=self.context['request'].user,
                action='created'
            )
            # Send console log notification
            print(f"Task '{task.title}' assigned to {task.assigned_to.username}")
            # You can add email notification here too
            return task

        def update(self, instance, validated_data):
            previous_status = instance.status
            task = super().update(instance, validated_data)
            action = 'updated'
            if validated_data.get('status') == 'completed' and previous_status != 'completed':
                action = 'completed'
            ActivityLog.objects.create(
                task=task,
                user=self.context['request'].user,
                action=action
            )
            return task

class ActivityLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = ActivityLog
        fields = '__all__'
