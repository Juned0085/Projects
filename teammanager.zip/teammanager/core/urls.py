from django.urls import path
from .views import RegisterView, ProjectListCreateView, TaskListCreateView, UserListView, ProjectDetailView, \
    TaskDetailView, ActivityLogListView, my_tasks
from django.contrib.auth import views as auth_views
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from . import views

urlpatterns = [
    # Api endpoints
    path('register/', RegisterView.as_view()),
    path('login/', TokenObtainPairView.as_view()),
    path('token/refresh/', TokenRefreshView.as_view()),
    path('projects/', ProjectListCreateView.as_view()),
    path('projects/<int:pk>/', ProjectDetailView.as_view(), name='project-detail'),
    path('tasks/<int:pk>/', TaskDetailView.as_view(), name='task-detail'),
    path('tasks/', TaskListCreateView.as_view()),
    path('users/', UserListView.as_view()),
    path('activity-logs/', ActivityLogListView.as_view()),


    # Template views
    path('tasks/', views.task_list_view, name='task-list'),
    path('login-page/', views.login_view, name='login'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('my-tasks/', my_tasks, name='my_tasks'),
    path('logout/', views.logout_view, name='logout'),
    path('my-tasks/', views.user_tasks_view, name='my_tasks'),
    path('task/update-status/<int:task_id>/', views.update_task_status, name='update_task_status'),
    path('admin/users/', views.user_list, name='user_list'),
    path('admin/projects/', views.project_list, name='project_list'),
    path('admin/tasks/', views.task_list_admin, name='task_list_admin'),
    path('my-tasks/', views.view_my_tasks, name='my_tasks'),
    path('update-task-status/<int:task_id>/', views.update_task_status, name='update_task_status'),



]

